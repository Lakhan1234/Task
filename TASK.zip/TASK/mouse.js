class Mouse {
    constructor(board) {
        this.board = board;
        this.canvas = board.canvas;
        this.drawX = 0;
        this.drawY = 0;
        this.addListeners();
    }
    addListeners() {
        this.canvas.addEventListener("mousemove", (event) => {
            event.preventDefault(); 
            let x = Math.floor(event.offsetX/ this.board.cellSize)
            if(!event.ctrlKey) this.drawX = x;
            let y = Math.floor(event.offsetY / this.board.cellSize)
            if(!event.shiftKey) this.drawY = y;

            if(event.buttons == 0 ) return
            this.board.traceNode(this.drawX,this.drawY)
          });
          this.canvas.addEventListener("mousedown",() => {
              event.preventDefault(); 
              this.drawX = Math.floor(event.offsetX/ this.board.cellSize)
              this.drawY = Math.floor(event.offsetY / this.board.cellSize)
              this.board.traceNode(this.drawX,this.drawY)
          });
    }
}